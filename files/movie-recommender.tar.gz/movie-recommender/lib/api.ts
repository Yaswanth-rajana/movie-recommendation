import {
  MovieCard,
  MovieDetails,
  RecommendationItem,
  EventPayload,
  Category,
} from "@/types/api";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

class ApiClient {
  private async fetch<T>(endpoint: string): Promise<T> {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`);
    }

    return response.json();
  }

  private async post<T>(endpoint: string, data: unknown): Promise<T> {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`);
    }

    return response.json();
  }

  async getHomeMovies(
    category: Category,
    limit: number = 20
  ): Promise<MovieCard[]> {
    return this.fetch<MovieCard[]>(`/home?category=${category}&limit=${limit}`);
  }

  async searchMovies(query: string, limit: number = 20): Promise<MovieCard[]> {
    const encodedQuery = encodeURIComponent(query);
    return this.fetch<MovieCard[]>(`/search?query=${encodedQuery}&limit=${limit}`);
  }

  async getMovieDetails(tmdbId: number): Promise<MovieDetails> {
    return this.fetch<MovieDetails>(`/movie/${tmdbId}`);
  }

  async getRecommendations(
    movieTitle: string,
    sessionId: string,
    topN: number = 10
  ): Promise<RecommendationItem[]> {
    const encodedTitle = encodeURIComponent(movieTitle);
    return this.fetch<RecommendationItem[]>(
      `/recommend/tfidf?title=${encodedTitle}&top_n=${topN}&session_id=${sessionId}`
    );
  }

  async trackEvent(payload: EventPayload): Promise<void> {
    await this.post("/events", payload);
  }
}

export const api = new ApiClient();

// Session ID management
export function getSessionId(): string {
  if (typeof window === "undefined") return "";
  
  let sessionId = localStorage.getItem("movie_session_id");
  if (!sessionId) {
    sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem("movie_session_id", sessionId);
  }
  return sessionId;
}
