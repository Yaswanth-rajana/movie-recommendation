"use client";

import { motion } from "framer-motion";
import { Play, Info, Star } from "lucide-react";
import Image from "next/image";
import { MovieDetails } from "@/types/api";
import { formatRating, formatYear, formatRuntime } from "@/lib/utils";

interface HeroSectionProps {
  movie: MovieDetails | null;
  onPlayClick: () => void;
  onInfoClick: () => void;
}

export function HeroSection({ movie, onPlayClick, onInfoClick }: HeroSectionProps) {
  if (!movie) {
    return (
      <div className="relative h-[70vh] w-full bg-cinema-darker animate-pulse" />
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="relative h-[85vh] w-full overflow-hidden"
    >
      {/* Background Image */}
      {movie.backdrop_url && (
        <div className="absolute inset-0">
          <Image
            src={movie.backdrop_url}
            alt={movie.title}
            fill
            priority
            className="object-cover object-center"
            sizes="100vw"
          />
          {/* Vignette effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-cinema-black via-transparent to-cinema-black/80" />
          <div className="absolute inset-0 bg-gradient-to-t from-cinema-black via-cinema-black/40 to-transparent" />
        </div>
      )}

      {/* Content */}
      <div className="relative z-10 flex h-full items-end pb-20">
        <div className="container mx-auto px-6 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="max-w-2xl"
          >
            {/* Title */}
            <h1 className="mb-4 font-display text-5xl font-black leading-tight text-white md:text-7xl lg:text-8xl">
              {movie.title}
            </h1>

            {/* Meta info */}
            <div className="mb-4 flex flex-wrap items-center gap-4 text-sm text-gray-300">
              <div className="flex items-center gap-1.5 rounded-full bg-black/40 px-3 py-1 backdrop-blur-sm">
                <Star className="h-4 w-4 fill-cinema-gold text-cinema-gold" />
                <span className="font-bold text-white">
                  {formatRating(movie.vote_average)}
                </span>
              </div>
              {movie.release_date && (
                <span className="font-semibold">{formatYear(movie.release_date)}</span>
              )}
              {movie.runtime && (
                <span className="font-semibold">{formatRuntime(movie.runtime)}</span>
              )}
              {movie.genres && movie.genres.length > 0 && (
                <span className="font-semibold">{movie.genres.slice(0, 3).join(" • ")}</span>
              )}
            </div>

            {/* Tagline */}
            {movie.tagline && (
              <p className="mb-4 font-display text-lg italic text-gray-300">
                {movie.tagline}
              </p>
            )}

            {/* Overview */}
            <p className="mb-8 max-w-xl text-base leading-relaxed text-gray-200 md:text-lg">
              {movie.overview}
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onPlayClick}
                className="flex items-center gap-3 rounded-lg bg-white px-8 py-3.5 font-display text-base font-bold text-black transition-colors hover:bg-gray-200"
              >
                <Play className="h-5 w-5 fill-current" />
                <span>Watch Now</span>
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onInfoClick}
                className="flex items-center gap-3 rounded-lg bg-white/20 px-8 py-3.5 font-display text-base font-bold text-white backdrop-blur-sm transition-colors hover:bg-white/30"
              >
                <Info className="h-5 w-5" />
                <span>More Info</span>
              </motion.button>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom fade */}
      <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-cinema-black to-transparent" />
    </motion.div>
  );
}
